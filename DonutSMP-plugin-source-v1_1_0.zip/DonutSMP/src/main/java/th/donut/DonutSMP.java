package th.donut;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.*;
import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Container;
import org.bukkit.block.Sign;
import org.bukkit.block.TileState;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.sign.Side;
import org.bukkit.block.sign.SignSide;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DonutSMP extends JavaPlugin implements Listener, TabExecutor {

    // ---------- โครงสร้างข้อมูล ----------
    static class Gui implements InventoryHolder {
        final String type;
        Inventory inv;
        int page;
        List<Order> orders = new ArrayList<>();
        List<Listing> shown = new ArrayList<>();
        List<String> names = new ArrayList<>();
        List<Material> mats = new ArrayList<>();
        SpawnerData sp;
        List<List<ItemStack>> goods = new ArrayList<>();
        List<Long> prices = new ArrayList<>();
        Map<Integer, Integer> slotIdx = new HashMap<>();
        Order order;
        String search;
        Gui(String type) { this.type = type; }
        @Override public Inventory getInventory() { return inv; }
    }

    static class Order {
        final int id; final UUID owner; final Material mat; int left; int delivered; final double price;
        Order(int id, UUID owner, Material mat, int left, double price) {
            this.id = id; this.owner = owner; this.mat = mat; this.left = left; this.price = price;
        }
    }

    static class Listing {
        final int id; final UUID seller; final ItemStack item; final double price; final long time;
        Listing(int id, UUID seller, ItemStack item, double price, long time) {
            this.id = id; this.seller = seller; this.item = item; this.price = price; this.time = time;
        }
    }

    static class TpaReq {
        final UUID from; final boolean here; final long expire;
        TpaReq(UUID from, boolean here, long expire) { this.from = from; this.here = here; this.expire = expire; }
    }

    static class SpawnerData {
        final String id, world; final UUID owner; final EntityType type; final int x, y, z;
        int stack = 1; long xp = 0;
        final Map<Material, Long> items = new HashMap<>();
        final Set<Material> disabled = new HashSet<>();
        SpawnerData(UUID owner, EntityType type, String world, int x, int y, int z) {
            this.owner = owner; this.type = type; this.world = world; this.x = x; this.y = y; this.z = z;
            this.id = world + ":" + x + "," + y + "," + z;
        }
    }

    private final Map<String, SpawnerData> spawners = new HashMap<>();
    private final Map<UUID, Double> money = new HashMap<>();
    private final Map<UUID, Long> shards = new HashMap<>();
    private final Map<UUID, Long> playSeconds = new HashMap<>();
    private final List<Order> orders = new ArrayList<>();
    private final List<Listing> listings = new ArrayList<>();
    private final Map<UUID, Map<String, Integer>> claims = new HashMap<>();
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private final Map<UUID, TpaReq> tpaReqs = new HashMap<>();
    private final Map<UUID, String> teamInvites = new HashMap<>();
    private NamespacedKey toolKey;
    private boolean multiBreaking = false;
    private List<Material> allItems;
    private final Map<String, SignSession> signSessions = new HashMap<>();
    private final Map<UUID, String> signByPlayer = new HashMap<>();

    static class SignSession {
        UUID player; String kind; Location loc; BlockData original;
        Material mat; double price; String search;
        BukkitTask timeout;
    }
    private int nextOrderId = 1;
    private int nextListingId = 1;
    private long keyallNext;
    private File dataFile;
    private YamlConfiguration data;

    // ---------- เปิด/ปิดปลั๊กอิน ----------
    @Override
    public void onEnable() {
        // ถ้า config เก่า (เวอร์ชันต่ำกว่า 2) ให้ย้ายไปเป็น config-old.yml แล้วสร้างใหม่
        File cf = new File(getDataFolder(), "config.yml");
        if (cf.exists() && YamlConfiguration.loadConfiguration(cf).getInt("config-version", 1) < 5) {
            File old = new File(getDataFolder(), "config-old.yml");
            if (old.exists()) old.delete();
            cf.renameTo(old);
        }
        toolKey = new NamespacedKey(this, "tool3x3");
        saveDefaultConfig();
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("shop", "sell", "order", "ah", "rtp", "sethome", "home", "delhome", "homes",
                "balance", "pay", "tpa", "tphere", "tpaccept", "tpdeny", "tpauto", "settings", "nv", "team", "eco", "rules", "spawner", "shardshop", "shards", "help-smp", "givera")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::saveData, 6000L, 6000L);
        long siv = Math.max(1, getConfig().getLong("spawner.interval-seconds", 15)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, this::produceAll, siv, siv);
        Bukkit.getOnlinePlayers().forEach(this::setupBoard);
    }

    @Override
    public void onDisable() {
        for (UUID pid : new ArrayList<>(signByPlayer.keySet())) endSign(pid);
        for (Player pl : Bukkit.getOnlinePlayers()) {
            if (pl.getOpenInventory().getTopInventory().getHolder(false) instanceof Gui g
                    && (g.type.equals("sell") || g.type.equals("orderdeposit"))) pl.closeInventory();
        }
        saveData();
    }

    void tick() {
        long now = System.currentTimeMillis();
        if (now >= keyallNext) {
            keyall();
            keyallNext = now + keyallInterval();
        }
        long per = getConfig().getLong("shards.per-minutes", 10) * 60;
        long amt = getConfig().getLong("shards.amount", 1);
        for (Player p : Bukkit.getOnlinePlayers()) {
            long t = playSeconds.merge(p.getUniqueId(), 1L, Long::sum);
            if (per > 0 && t % per == 0) {
                shards.merge(p.getUniqueId(), amt, Long::sum);
                if (getConfig().getBoolean("shards.notify", false)) msg(p, "&dคุณได้รับ &f" + amt + " &dShards จากการเล่น!");
            }
            updateBoard(p);
        }
    }

    long keyallInterval() { return Math.max(1, getConfig().getLong("keyall.interval-minutes", 60)) * 60_000L; }

    void keyall() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            msg(p, "&9&lKEYALL! &fทุกคนได้รับรางวัลแล้ว");
            if (getConfig().getBoolean("keyall.give-armor-set", true)) giveArmorSet(p);
            for (String cmd : getConfig().getStringList("keyall.commands"))
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
        }
    }

    // ---------- Utility ----------
    String c(String s) { return ChatColor.translateAlternateColorCodes('&', s); }

    void msg(CommandSender s, String m) { s.sendMessage(c(getConfig().getString("prefix", "") + m)); }

    double bal(UUID id) { return money.getOrDefault(id, 0.0); }

    void add(UUID id, double amt) { money.put(id, Math.max(0, bal(id) + amt)); }

    boolean take(UUID id, double amt) {
        if (bal(id) < amt) return false;
        money.put(id, bal(id) - amt);
        return true;
    }

    static String fmt(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        while (v >= 1000 && i < suf.length - 1) { v /= 1000; i++; }
        if (i == 0) return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.1f", v);
        String s = String.format(Locale.US, "%.1f", v);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s + suf[i];
    }

    static String hms(long s) { return (s / 3600) + "h " + (s % 3600 / 60) + "m " + (s % 60) + "s"; }

    static String shortTime(long s) {
        long h = s / 3600, m = s % 3600 / 60, x = s % 60;
        return h > 0 ? h + "h " + m + "m " + x + "s" : m + "m " + x + "s";
    }

    double parseAmount(String s) {
        try {
            s = s.toLowerCase(Locale.ROOT).replace(",", "");
            double mul = 1;
            if (s.endsWith("k")) mul = 1e3;
            else if (s.endsWith("m")) mul = 1e6;
            else if (s.endsWith("b")) mul = 1e9;
            if (mul != 1) s = s.substring(0, s.length() - 1);
            double v = Double.parseDouble(s) * mul;
            return (Double.isNaN(v) || Double.isInfinite(v)) ? -1 : v;
        } catch (Exception e) { return -1; }
    }

    void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        left.values().forEach(r -> p.getWorld().dropItemNaturally(p.getLocation(), r));
    }

    ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta mt = it.getItemMeta();
        mt.setDisplayName(c(name));
        if (lore.length > 0) mt.setLore(Arrays.stream(lore).map(this::c).collect(Collectors.toList()));
        it.setItemMeta(mt);
        return it;
    }

    boolean setting(UUID id, String key, boolean def) { return data.getBoolean("settings." + id + "." + key, def); }

    void setSetting(UUID id, String key, boolean v) { data.set("settings." + id + "." + key, v); }

    List<String> names(String prefix) {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).collect(Collectors.toList());
    }

    List<String> mobs(String prefix) {
        return Arrays.stream(EntityType.values()).filter(EntityType::isAlive).map(t -> t.name().toLowerCase(Locale.ROOT))
                .filter(k -> k.startsWith(prefix.toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
    }

    void applyEnchants(ItemStack it, Collection<?> list) {
        for (Object o : list) {
            try {
                String[] a = String.valueOf(o).split(":");
                Enchantment en = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(a[0].toLowerCase(Locale.ROOT)));
                if (en != null) it.addUnsafeEnchantment(en, a.length > 1 ? Integer.parseInt(a[1]) : 1);
            } catch (Exception ignored) { }
        }
    }

    void giveArmorSet(Player p) {
        for (Material m : new Material[]{Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS}) {
            ItemStack it = new ItemStack(m);
            applyEnchants(it, getConfig().getStringList("keyall.armor-enchants"));
            give(p, it);
        }
    }

    void shardsCmd(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length >= 3 && a[0].equalsIgnoreCase("pay")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            long amt = (long) parseAmount(a[2]);
            if (t == null || t == p || amt <= 0) { msg(p, "&cข้อมูลไม่ถูกต้อง"); return; }
            if (shards.getOrDefault(id, 0L) < amt) { msg(p, "&cShards ไม่พอ"); return; }
            shards.merge(id, -amt, Long::sum);
            shards.merge(t.getUniqueId(), amt, Long::sum);
            msg(p, "&aโอน &d" + fmt(amt) + " Shards &aให้ " + t.getName());
            msg(t, "&aได้รับ &d" + fmt(amt) + " Shards &aจาก " + p.getName());
            return;
        }
        msg(p, "&dShards ของคุณ: &f" + fmt(shards.getOrDefault(id, 0L)) + " &7| /shardshop เปิดร้านค้า | /shards pay <ผู้เล่น> <จำนวน>");
    }

    void openShardShop(Player p) {
        Gui g = new Gui("shardshop");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shardshop.title", "&5&lShard Shop")));
        int auto = 10;
        for (Map<?, ?> m : getConfig().getMapList("shardshop.items")) {
            try {
                List<String> ench = new ArrayList<>();
                if (m.get("enchants") instanceof List<?> el) for (Object o : el) ench.add(String.valueOf(o));
                List<ItemStack> goods = new ArrayList<>();
                ItemStack display;
                Object armorSet = m.get("armor-set");
                if (armorSet != null) {
                    for (String part : List.of("HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS")) {
                        Material pm = Material.matchMaterial(String.valueOf(armorSet).toUpperCase(Locale.ROOT) + "_" + part);
                        if (pm == null) continue;
                        ItemStack pi = new ItemStack(pm);
                        applyEnchants(pi, ench);
                        goods.add(pi);
                    }
                    if (goods.isEmpty()) continue;
                    display = goods.get(goods.size() > 1 ? 1 : 0).clone();
                } else {
                    Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                    if (mat == null) continue;
                    int amt = m.get("amount") instanceof Number nn ? nn.intValue() : 1;
                    ItemStack gi = new ItemStack(mat, Math.max(1, amt));
                    applyEnchants(gi, ench);
                    if (Boolean.TRUE.equals(m.get("tool3x3"))) make3x3(gi, m.get("name") != null ? String.valueOf(m.get("name")) : null);
                    goods.add(gi);
                    display = gi.clone();
                }
                long price = ((Number) m.get("price")).longValue();
                int slot = m.get("slot") instanceof Number sn ? sn.intValue() : auto++;
                if (slot < 0 || slot >= 54) continue;
                ItemMeta mt = display.getItemMeta();
                if (m.get("name") != null) mt.setDisplayName(c(String.valueOf(m.get("name"))));
                List<String> lore = new ArrayList<>();
                if (armorSet != null) lore.add(c("&7ได้ครบ 4 ชิ้น"));
                if (is3x3(display)) lore.add(c("&b⛏ ขุด 3×3 &7(ย่อตัว = ขุดบล็อกเดียว)"));
                lore.add(c("&7ราคา: &d" + fmt(price) + " Shards"));
                lore.add(c("&eคลิกเพื่อซื้อ"));
                mt.setLore(lore);
                display.setItemMeta(mt);
                g.slotIdx.put(slot, g.goods.size());
                g.goods.add(goods);
                g.prices.add(price);
                g.inv.setItem(slot, display);
            } catch (Exception ignored) { }
        }
        g.inv.setItem(49, item(Material.NETHER_STAR, "&dShards: &f" + fmt(shards.getOrDefault(p.getUniqueId(), 0L)), "&7เล่นเพื่อสะสม Shards"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    double sellPrice(Material m) { return getConfig().getDouble("sell." + m.name(), getConfig().getDouble("sell-default", 1)); }

    // ---------- เก็บข้อมูล ----------
    void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection m = data.getConfigurationSection("money");
        if (m != null) for (String k : m.getKeys(false)) money.put(UUID.fromString(k), m.getDouble(k));
        ConfigurationSection sh = data.getConfigurationSection("shards");
        if (sh != null) for (String k : sh.getKeys(false)) shards.put(UUID.fromString(k), sh.getLong(k));
        ConfigurationSection pt = data.getConfigurationSection("playtime");
        if (pt != null) for (String k : pt.getKeys(false)) playSeconds.put(UUID.fromString(k), pt.getLong(k));
        ConfigurationSection os = data.getConfigurationSection("orders");
        if (os != null) for (String k : os.getKeys(false)) {
            ConfigurationSection s = os.getConfigurationSection(k);
            Material mat = Material.matchMaterial(s.getString("item", ""));
            if (mat == null) continue;
            int id = Integer.parseInt(k);
            Order lo = new Order(id, UUID.fromString(s.getString("owner")), mat, s.getInt("left"), s.getDouble("price"));
            lo.delivered = s.getInt("delivered");
            orders.add(lo);
            nextOrderId = Math.max(nextOrderId, id + 1);
        }
        ConfigurationSection as = data.getConfigurationSection("auctions");
        if (as != null) for (String k : as.getKeys(false)) {
            ConfigurationSection s = as.getConfigurationSection(k);
            ItemStack it = s.getItemStack("item");
            if (it == null) continue;
            int id = Integer.parseInt(k);
            listings.add(new Listing(id, UUID.fromString(s.getString("seller")), it, s.getDouble("price"), s.getLong("time")));
            nextListingId = Math.max(nextListingId, id + 1);
        }
        ConfigurationSection cs = data.getConfigurationSection("claims");
        if (cs != null) for (String owner : cs.getKeys(false)) {
            Map<String, Integer> map = new HashMap<>();
            ConfigurationSection items = cs.getConfigurationSection(owner);
            for (String mat : items.getKeys(false)) map.put(mat, items.getInt(mat));
            claims.put(UUID.fromString(owner), map);
        }
        ConfigurationSection sps = data.getConfigurationSection("spawners");
        if (sps != null) for (String k : sps.getKeys(false)) {
            ConfigurationSection sc = sps.getConfigurationSection(k);
            try {
                SpawnerData sd = new SpawnerData(UUID.fromString(sc.getString("owner")), EntityType.valueOf(sc.getString("type")),
                        sc.getString("world"), sc.getInt("x"), sc.getInt("y"), sc.getInt("z"));
                sd.stack = Math.max(1, sc.getInt("stack", 1));
                sd.xp = sc.getLong("xp");
                for (String dn : sc.getStringList("disabled")) {
                    Material dm = Material.matchMaterial(dn);
                    if (dm != null) sd.disabled.add(dm);
                }
                ConfigurationSection its = sc.getConfigurationSection("items");
                if (its != null) for (String mk : its.getKeys(false)) {
                    Material mm = Material.matchMaterial(mk);
                    if (mm != null) sd.items.put(mm, its.getLong(mk));
                }
                spawners.put(sd.id, sd);
            } catch (Exception ex) { getLogger().warning("bad spawner entry " + k); }
        }
        keyallNext = data.getLong("keyall.next", 0);
        if (keyallNext <= System.currentTimeMillis()) keyallNext = System.currentTimeMillis() + keyallInterval();
    }

    void saveData() {
        data.set("money", null);
        money.forEach((k, v) -> data.set("money." + k, v));
        data.set("shards", null);
        shards.forEach((k, v) -> data.set("shards." + k, v));
        data.set("playtime", null);
        playSeconds.forEach((k, v) -> data.set("playtime." + k, v));
        data.set("orders", null);
        for (Order o : orders) {
            String p = "orders." + o.id + ".";
            data.set(p + "owner", o.owner.toString());
            data.set(p + "item", o.mat.name());
            data.set(p + "left", o.left);
            data.set(p + "price", o.price);
            data.set(p + "delivered", o.delivered);
        }
        data.set("auctions", null);
        for (Listing l : listings) {
            String p = "auctions." + l.id + ".";
            data.set(p + "seller", l.seller.toString());
            data.set(p + "item", l.item);
            data.set(p + "price", l.price);
            data.set(p + "time", l.time);
        }
        data.set("claims", null);
        claims.forEach((k, map) -> map.forEach((mat, n) -> data.set("claims." + k + "." + mat, n)));
        data.set("spawners", null);
        int si = 0;
        for (SpawnerData sd : spawners.values()) {
            String b = "spawners." + (si++) + ".";
            data.set(b + "world", sd.world);
            data.set(b + "x", sd.x); data.set(b + "y", sd.y); data.set(b + "z", sd.z);
            data.set(b + "owner", sd.owner.toString());
            data.set(b + "type", sd.type.name());
            data.set(b + "stack", sd.stack);
            data.set(b + "xp", sd.xp);
            if (!sd.disabled.isEmpty()) data.set(b + "disabled", sd.disabled.stream().map(Enum::name).collect(Collectors.toList()));
            for (Map.Entry<Material, Long> en : sd.items.entrySet()) data.set(b + "items." + en.getKey().name(), en.getValue());
        }
        data.set("keyall.next", keyallNext);
        try { data.save(dataFile); } catch (IOException e) { getLogger().warning("save failed: " + e.getMessage()); }
    }

    // ---------- Scoreboard ----------
    String teamName(UUID id) {
        String key = data.getString("playerTeam." + id);
        if (key == null) return "none";
        return data.getString("teams." + key + ".name", "none");
    }

    void setupBoard(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective o = sb.registerNewObjective("donut", Criteria.DUMMY, c(getConfig().getString("scoreboard.title", "DONUT SMP")));
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        int n = Math.min(15, getConfig().getStringList("scoreboard.lines").size());
        for (int i = 0; i < n; i++) {
            Team t = sb.registerNewTeam("l" + i);
            String entry = "§" + Integer.toHexString(i) + "§r";
            t.addEntry(entry);
            o.getScore(entry).setScore(n - i);
        }
        p.setScoreboard(sb);
        updateBoard(p);
    }

    void updateBoard(Player p) {
        UUID id = p.getUniqueId();
        Scoreboard sb = p.getScoreboard();
        Objective side = sb.getObjective("donut");
        if (side == null) { setupBoard(p); return; }
        boolean showSide = setting(id, "scoreboard", true);
        if (showSide && side.getDisplaySlot() != DisplaySlot.SIDEBAR) side.setDisplaySlot(DisplaySlot.SIDEBAR);
        if (!showSide && side.getDisplaySlot() != null) side.setDisplaySlot(null);
        updateNametags(sb);
        if (!showSide) return;
        List<String> lines = getConfig().getStringList("scoreboard.lines");
        long keyLeft = Math.max(0, (keyallNext - System.currentTimeMillis()) / 1000);
        for (int i = 0; i < Math.min(15, lines.size()); i++) {
            Team t = sb.getTeam("l" + i);
            if (t == null) continue;
            String line = lines.get(i)
                    .replace("{money}", fmt(bal(id)))
                    .replace("{shards}", fmt(shards.getOrDefault(id, 0L)))
                    .replace("{kills}", String.valueOf(p.getStatistic(Statistic.PLAYER_KILLS)))
                    .replace("{deaths}", String.valueOf(p.getStatistic(Statistic.DEATHS)))
                    .replace("{keyall}", shortTime(keyLeft))
                    .replace("{playtime}", hms(playSeconds.getOrDefault(id, 0L)))
                    .replace("{team}", teamName(id))
                    .replace("{player}", p.getName())
                    .replace("{rank}", rankPrefix(id))
                    .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()));
            t.setPrefix(c(line));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (!money.containsKey(p.getUniqueId())) money.put(p.getUniqueId(), getConfig().getDouble("start-money", 0));
        setupBoard(p);
    }

    // ---------- Rank / ยศ (OWNER, ADMIN, CAMERA = create) ----------
    String rankKey(UUID id) {
        String k = data.getString("ranks." + id);
        if (k == null) return null;
        return getConfig().isConfigurationSection("ranks.list." + k) ? k : null;
    }

    String rankPrefix(UUID id) {
        String k = rankKey(id);
        if (k == null) return "";
        return getConfig().getString("ranks.list." + k + ".prefix", "&7[" + k + "] &r");
    }

    int rankPriority(UUID id) {
        String k = rankKey(id);
        if (k == null) return 9;
        return Math.max(0, Math.min(8, getConfig().getInt("ranks.list." + k + ".priority", 5)));
    }

    String normalizeRank(String in) {
        String r = in.toLowerCase(Locale.ROOT);
        if (r.equals("owner")) return "OWNER";
        if (r.equals("admin")) return "ADMIN";
        if (r.contains("+") || r.contains("\uD83D\uDCF7") || r.equals("camera") || r.equals("cam")
                || r.equals("create") || r.equals("creator")) return "CAMERA";
        return null;
    }

    // ยศหน้าชื่อ (เหนือหัว + แท็บ) และเงินใต้ชื่อ
    void updateNametags(Scoreboard sb) {
        Objective mo = sb.getObjective("dmoney");
        if (mo == null) {
            mo = sb.registerNewObjective("dmoney", Criteria.DUMMY, c("&a$"));
            mo.setDisplaySlot(DisplaySlot.BELOW_NAME);
        }
        Set<String> keep = new HashSet<>();
        for (Player t : Bukkit.getOnlinePlayers()) {
            UUID tid = t.getUniqueId();
            String tn = "n" + rankPriority(tid) + Integer.toHexString(tid.hashCode());
            keep.add(tn);
            Team team = sb.getTeam(tn);
            if (team == null) team = sb.registerNewTeam(tn);
            String pf = c(rankPrefix(tid));
            if (!pf.equals(team.getPrefix())) team.setPrefix(pf);
            if (!team.hasEntry(t.getName())) team.addEntry(t.getName());
            mo.getScore(t.getName()).setScore((int) Math.min(Integer.MAX_VALUE, bal(tid)));
        }
        for (Team t : new ArrayList<>(sb.getTeams())) {
            if (t.getName().startsWith("n") && !keep.contains(t.getName())) t.unregister();
        }
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        if (!getConfig().getBoolean("ranks.chat-enabled", true)) return;
        String pf = rankPrefix(e.getPlayer().getUniqueId());
        e.renderer(ChatRenderer.viewerUnaware((source, name, message) -> {
            Component out = Component.empty();
            if (!pf.isEmpty()) out = out.append(LegacyComponentSerializer.legacySection().deserialize(c(pf)));
            return out.append(name).append(Component.text(" \u00BB ", NamedTextColor.DARK_GRAY)).append(message);
        }));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { endSign(e.getPlayer().getUniqueId()); }

    // ---------- เครื่องมือขุด 3x3 ----------
    ItemStack make3x3(ItemStack it, String name) {
        ItemMeta mm = it.getItemMeta();
        mm.getPersistentDataContainer().set(toolKey, PersistentDataType.BYTE, (byte) 1);
        if (name != null) mm.setDisplayName(c(name));
        mm.setLore(List.of(c("&b⛏ ขุด 3×3"), c("&7ย่อตัว (Shift) = ขุดบล็อกเดียว")));
        it.setItemMeta(mm);
        return it;
    }

    boolean is3x3(ItemStack it) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(toolKey, PersistentDataType.BYTE);
    }

    boolean canMultiBreak(ItemStack tool, Block b) {
        Material t = b.getType();
        if (t.isAir() || b.isLiquid() || t == Material.SPAWNER || t.getHardness() < 0) return false;
        if (spawners.containsKey(key(b))) return false;
        String tn = tool.getType().name();
        Tag<Material> tag = tn.endsWith("_PICKAXE") ? Tag.MINEABLE_PICKAXE
                : tn.endsWith("_AXE") ? Tag.MINEABLE_AXE
                : tn.endsWith("_SHOVEL") ? Tag.MINEABLE_SHOVEL : null;
        if (tag == null || !tag.isTagged(t)) return false;
        return !(b.getState() instanceof Container);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onTool3x3(BlockBreakEvent e) {
        if (multiBreaking) return;
        Player p = e.getPlayer();
        if (p.isSneaking() || p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (!is3x3(tool)) return;
        Block center = e.getBlock();
        RayTraceResult rt = p.rayTraceBlocks(7.0);
        if (rt == null || rt.getHitBlock() == null || !rt.getHitBlock().equals(center) || rt.getHitBlockFace() == null) return;
        BlockFace face = rt.getHitBlockFace();
        boolean ax = face.getModX() != 0, ay = face.getModY() != 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i == 0 && j == 0) continue;
                int dx, dy, dz;
                if (ax) { dx = 0; dy = i; dz = j; }
                else if (ay) { dx = i; dy = 0; dz = j; }
                else { dx = i; dy = j; dz = 0; }
                Block b = center.getRelative(dx, dy, dz);
                if (!canMultiBreak(tool, b)) continue;
                BlockBreakEvent ev = new BlockBreakEvent(b, p);
                multiBreaking = true;
                try {
                    Bukkit.getPluginManager().callEvent(ev);
                    if (!ev.isCancelled()) b.breakNaturally(tool);
                } finally {
                    multiBreaking = false;
                }
            }
        }
    }

    // ---------- ป้ายให้พิมพ์ตัวเลข (Sign input) ----------
    void openSign(Player p, String kind, Material mat, double price, String search, String l1, String l2) {
        p.closeInventory();
        Bukkit.getScheduler().runTask(this, () -> {
            if (!p.isOnline()) return;
            endSign(p.getUniqueId());
            Block b = findSignSpot(p);
            if (b == null) { msg(p, "&cเปิดช่องกรอกตัวเลขตรงนี้ไม่ได้ ลองย้ายไปที่โล่งกว่านี้"); return; }
            SignSession ss = new SignSession();
            ss.player = p.getUniqueId(); ss.kind = kind; ss.mat = mat; ss.price = price; ss.search = search;
            ss.loc = b.getLocation(); ss.original = b.getBlockData();
            b.setType(Material.OAK_SIGN, false);
            Sign sign = (Sign) b.getState();
            SignSide side = sign.getSide(Side.FRONT);
            side.line(0, Component.empty());
            side.line(1, Component.text("^^^^^^^^^^^^^^"));
            side.line(2, Component.text(l1));
            side.line(3, Component.text(l2));
            sign.update(true, false);
            String k = key(b);
            signSessions.put(k, ss);
            signByPlayer.put(ss.player, k);
            ss.timeout = Bukkit.getScheduler().runTaskLater(this, () -> endSign(ss.player), 20L * 60);
            p.openSign(sign, Side.FRONT);
        });
    }

    Block findSignSpot(Player p) {
        Block base = p.getLocation().getBlock();
        World w = base.getWorld();
        Block fallback = null;
        for (int dy = 2; dy <= 6; dy++) {
            Block b = base.getRelative(0, dy, 0);
            if (b.getY() >= w.getMaxHeight() - 1) break;
            if (b.getType().isAir()) return b;
            if (fallback == null && !b.isLiquid() && !(b.getState() instanceof TileState)) fallback = b;
        }
        return fallback;
    }

    void endSign(UUID pid) {
        String k = signByPlayer.remove(pid);
        if (k == null) return;
        SignSession ss = signSessions.remove(k);
        if (ss == null) return;
        if (ss.timeout != null) ss.timeout.cancel();
        ss.loc.getBlock().setBlockData(ss.original, false);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPhysics(BlockPhysicsEvent e) {
        if (signSessions.isEmpty()) return;
        if (signSessions.containsKey(key(e.getBlock()))) e.setCancelled(true);
    }

    @EventHandler
    public void onSignChange(SignChangeEvent e) {
        SignSession ss = signSessions.get(key(e.getBlock()));
        if (ss == null) return;
        Player p = e.getPlayer();
        if (!p.getUniqueId().equals(ss.player)) return;
        e.setCancelled(true);
        Component l0 = e.line(0);
        String text = l0 == null ? "" : PlainTextComponentSerializer.plainText().serialize(l0).trim();
        endSign(ss.player);
        Bukkit.getScheduler().runTask(this, () -> signResult(p, ss, text));
    }

    void signResult(Player p, SignSession ss, String text) {
        if (!p.isOnline()) return;
        switch (ss.kind) {
            case "search" -> openPicker(p, 0, text.isEmpty() ? null : text);
            case "price" -> {
                if (text.isEmpty()) { openPicker(p, 0, ss.search); return; }
                double price = parseAmount(text);
                if (price <= 0) { msg(p, "&cราคาไม่ถูกต้อง"); openPicker(p, 0, ss.search); return; }
                openSign(p, "qty", ss.mat, price, ss.search, "จำนวนที่รับซื้อ", "เช่น 64 หรือ 1k");
            }
            case "qty" -> {
                if (text.isEmpty()) { openOrders(p, 0); return; }
                double q = parseAmount(text);
                if (q < 1 || q > Integer.MAX_VALUE) { msg(p, "&cจำนวนไม่ถูกต้อง"); openOrders(p, 0); return; }
                createOrder(p, ss.mat, (int) q, ss.price);
                openOrders(p, 0);
            }
            default -> { }
        }
    }

    // ---------- คำสั่ง ----------
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);

        if (n.equals("eco")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cไม่มีสิทธิ์"); return true; }
            if (a.length < 3) { msg(s, "&e/eco <give|set|take> <player> [money|shards|keyall] <amount>"); return true; }
            OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
            UUID tid = t.getUniqueId();
            String kind = "money";
            String amtStr = a[2];
            if (a.length >= 4) { kind = a[2].toLowerCase(Locale.ROOT); amtStr = a[3]; }
            double amt = parseAmount(amtStr);
            if (amt < 0) { msg(s, "&cจำนวนไม่ถูกต้อง"); return true; }
            String act = a[0].toLowerCase(Locale.ROOT);
            switch (kind) {
                case "money" -> {
                    switch (act) {
                        case "give" -> add(tid, amt);
                        case "take" -> add(tid, -amt);
                        case "set" -> money.put(tid, amt);
                        default -> { msg(s, "&cใช้ give/set/take"); return true; }
                    }
                    msg(s, "&aMoney ของ " + a[1] + " ตอนนี้ $" + fmt(bal(tid)));
                }
                case "shards" -> {
                    long v = (long) amt;
                    long cur = shards.getOrDefault(tid, 0L);
                    switch (act) {
                        case "give" -> shards.put(tid, cur + v);
                        case "take" -> shards.put(tid, Math.max(0, cur - v));
                        case "set" -> shards.put(tid, v);
                        default -> { msg(s, "&cใช้ give/set/take"); return true; }
                    }
                    msg(s, "&dShards ของ " + a[1] + " ตอนนี้ " + fmt(shards.getOrDefault(tid, 0L)));
                }
                case "keyall" -> {
                    Player tp = Bukkit.getPlayer(tid);
                    if (!act.equals("give")) { msg(s, "&cKeyall ใช้ได้เฉพาะ give"); return true; }
                    if (tp == null) { msg(s, "&cผู้เล่นต้องออนไลน์"); return true; }
                    int sets = (int) Math.max(1, Math.min(64, amt));
                    for (int i = 0; i < sets; i++) giveArmorSet(tp);
                    msg(s, "&aให้ชุดเกราะเพชร (Keyall) x" + sets + " แก่ " + tp.getName());
                }
                default -> msg(s, "&cชนิดต้องเป็น money / shards / keyall");
            }
            return true;
        }

        if (n.equals("help-smp")) {
            s.sendMessage(c("&6&l===== คำสั่งทั้งหมดใน SMP ====="));
            Map<String, Map<String, Object>> cmds = new TreeMap<>(getDescription().getCommands());
            for (Map.Entry<String, Map<String, Object>> en : cmds.entrySet()) {
                Object perm = en.getValue().get("permission");
                if (perm != null && !s.hasPermission(String.valueOf(perm))) continue;
                Object desc = en.getValue().get("description");
                s.sendMessage(c("&e/" + en.getKey() + " &8- &f" + (desc == null ? "" : desc)));
            }
            return true;
        }

        if (n.equals("givera")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cไม่มีสิทธิ์"); return true; }
            if (a.length < 2) { msg(s, "&e/givera <ผู้เล่น> <OWNER|ADMIN|CAMERA|remove> &7(CAMERA = ยศ +\uD83D\uDCF7 สำหรับ create)"); return true; }
            OfflinePlayer gt = Bukkit.getOfflinePlayer(a[0]);
            if (!gt.isOnline() && !gt.hasPlayedBefore()) { msg(s, "&cไม่พบผู้เล่นชื่อนี้"); return true; }
            String want = a[1].toLowerCase(Locale.ROOT);
            if (want.equals("remove") || want.equals("none") || want.equals("clear")) {
                data.set("ranks." + gt.getUniqueId(), null);
                msg(s, "&aลบยศของ " + a[0] + " แล้ว");
            } else {
                String rk = normalizeRank(a[1]);
                if (rk == null) { msg(s, "&cยศต้องเป็น OWNER / ADMIN / CAMERA (หรือ remove)"); return true; }
                data.set("ranks." + gt.getUniqueId(), rk);
                msg(s, "&aให้ยศ &f" + c(getConfig().getString("ranks.list." + rk + ".prefix", rk)) + "&a แก่ " + a[0]);
                Player on = gt.getPlayer();
                if (on != null) msg(on, "&aคุณได้รับยศ &f" + c(getConfig().getString("ranks.list." + rk + ".prefix", rk)));
            }
            Bukkit.getOnlinePlayers().forEach(this::updateBoard);
            return true;
        }

        if (n.equals("spawner")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cไม่มีสิทธิ์"); return true; }
            if (a.length >= 2 && a[0].equalsIgnoreCase("fill")) {
                if (!(s instanceof Player fp)) { msg(s, "&cเฉพาะผู้เล่น"); return true; }
                EntityType ft;
                try { ft = EntityType.valueOf(a[1].toUpperCase(Locale.ROOT)); } catch (Exception ex) { ft = null; }
                if (ft == null) { msg(s, "&cไม่พบชนิดมอนสเตอร์"); return true; }
                int size = 3, stk = 1;
                try { if (a.length > 2) size = Integer.parseInt(a[2]); } catch (NumberFormatException ex) { size = 3; }
                try { if (a.length > 3) stk = Integer.parseInt(a[3]); } catch (NumberFormatException ex) { stk = 1; }
                size = Math.max(1, Math.min(size, getConfig().getInt("spawner.fill-max-size", 16)));
                stk = Math.max(1, Math.min(stk, getConfig().getInt("spawner.max-stack", 1000)));
                World fw = fp.getWorld();
                int cx = fp.getLocation().getBlockX(), cy = fp.getLocation().getBlockY(), cz = fp.getLocation().getBlockZ();
                int half = size / 2, placed = 0;
                for (int dx = 0; dx < size; dx++) {
                    for (int dy = 0; dy < size; dy++) {
                        for (int dz = 0; dz < size; dz++) {
                            int x = cx - half + dx, y = cy - half + dy, z = cz - half + dz;
                            if (x == cx && z == cz && (y == cy || y == cy + 1)) continue; // ไม่เสกทับตัวผู้เล่น
                            if (y < fw.getMinHeight() || y >= fw.getMaxHeight()) continue;
                            placeSpawner(fw, x, y, z, ft, stk, fp.getUniqueId());
                            placed++;
                        }
                    }
                }
                msg(s, "&aเสก " + nice(ft) + " Spawner เป็นบล็อก " + placed + " อัน (ซ้อนอันละ x" + stk + ") รอบตัวคุณ ขนาด " + size + "x" + size + "x" + size);
                return true;
            }
            if (a.length >= 2 && a[0].equalsIgnoreCase("fillinv")) {
                if (!(s instanceof Player fp)) { msg(s, "&cเฉพาะผู้เล่น"); return true; }
                EntityType ft;
                try { ft = EntityType.valueOf(a[1].toUpperCase(Locale.ROOT)); } catch (Exception ex) { ft = null; }
                if (ft == null) { msg(s, "&cไม่พบชนิดมอนสเตอร์"); return true; }
                ItemStack[] cont = fp.getInventory().getStorageContents();
                int filled = 0;
                for (int i = 0; i < cont.length; i++) {
                    if (cont[i] == null || cont[i].getType().isAir()) { cont[i] = spawnerItem(ft, 64); filled++; }
                }
                fp.getInventory().setStorageContents(cont);
                msg(s, "&aเสก " + nice(ft) + " Spawner x64 ลงช่องว่าง " + filled + " ช่อง");
                return true;
            }
            if (a.length < 3 || !a[0].equalsIgnoreCase("give")) { msg(s, "&e/spawner give <player> <mob> [amount] | fill <mob> [ขนาด] [ซ้อน] | fillinv <mob>"); return true; }
            Player t = Bukkit.getPlayerExact(a[1]);
            EntityType et;
            try { et = EntityType.valueOf(a[2].toUpperCase(Locale.ROOT)); } catch (Exception ex) { et = null; }
            if (t == null || et == null) { msg(s, "&cไม่พบผู้เล่นหรือชนิดมอนสเตอร์"); return true; }
            int amt = 1;
            if (a.length > 3) { try { amt = Math.max(1, Math.min(64, Integer.parseInt(a[3]))); } catch (NumberFormatException ex) { amt = 1; } }
            give(t, spawnerItem(et, amt));
            msg(s, "&aให้ " + nice(et) + " Spawner x" + amt + " แก่ " + t.getName());
            return true;
        }

        if (!(s instanceof Player p)) { s.sendMessage("เฉพาะผู้เล่นเท่านั้น"); return true; }
        UUID id = p.getUniqueId();

        switch (n) {
            case "shop" -> openShop(p);
            case "sell" -> openSell(p);
            case "order" -> orderCmd(p, a);
            case "ah" -> ahCmd(p, a);
            case "rtp" -> rtpCmd(p, a);
            case "balance" -> msg(p, "&eเงินของคุณ: &a$" + fmt(bal(id)));
            case "pay" -> pay(p, a);
            case "tpa" -> tpaCmd(p, a, false);
            case "tphere" -> tpaCmd(p, a, true);
            case "tpaccept" -> tpRespond(p, true);
            case "tpdeny" -> tpRespond(p, false);
            case "tpauto" -> {
                boolean v = !setting(id, "tpauto", false);
                setSetting(id, "tpauto", v);
                msg(p, "&eรับ TPA อัตโนมัติ: " + (v ? "&aเปิด" : "&cปิด"));
            }
            case "settings" -> openSettings(p);
            case "nv" -> {
                if (p.hasPotionEffect(PotionEffectType.NIGHT_VISION)) {
                    p.removePotionEffect(PotionEffectType.NIGHT_VISION);
                    msg(p, "&eมองเห็นกลางคืน: &cปิด");
                } else {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, false, false, false));
                    msg(p, "&eมองเห็นกลางคืน: &aเปิด");
                }
            }
            case "team" -> teamCmd(p, a);
            case "sethome" -> {
                String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
                String base = "homes." + id;
                ConfigurationSection hs = data.getConfigurationSection(base);
                int count = hs == null ? 0 : hs.getKeys(false).size();
                boolean exists = hs != null && hs.contains(name);
                if (!exists && count >= getConfig().getInt("homes.max", 3)) { msg(p, "&cคุณตั้งบ้านได้สูงสุด " + getConfig().getInt("homes.max", 3) + " หลัง"); return true; }
                data.set(base + "." + name, p.getLocation());
                msg(p, "&aตั้งบ้าน &e" + name + " &aแล้ว");
            }
            case "home" -> {
                String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
                Location l = data.getLocation("homes." + id + "." + name);
                if (l == null) { msg(p, "&cไม่พบบ้านชื่อ " + name); return true; }
                p.teleportAsync(l);
                msg(p, "&aวาปไปบ้าน &e" + name);
            }
            case "delhome" -> {
                if (a.length < 1) { msg(p, "&e/delhome <name>"); return true; }
                String path = "homes." + id + "." + a[0].toLowerCase(Locale.ROOT);
                if (!data.contains(path)) { msg(p, "&cไม่พบบ้านนี้"); return true; }
                data.set(path, null);
                msg(p, "&aลบบ้านแล้ว");
            }
            case "homes" -> openHomes(p);
            case "rules" -> openRules(p);
            case "shardshop" -> openShardShop(p);
            case "shards" -> shardsCmd(p, a);
        }
        return true;
    }

    void pay(Player p, String[] a) {
        if (a.length < 2) { msg(p, "&e/pay <player> <amount>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        double amt = parseAmount(a[1]);
        if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
        if (amt <= 0) { msg(p, "&cจำนวนไม่ถูกต้อง"); return; }
        if (!setting(t.getUniqueId(), "pay", true)) { msg(p, "&cผู้เล่นนี้ปิดรับเงินโอน"); return; }
        if (!take(p.getUniqueId(), amt)) { msg(p, "&cเงินไม่พอ"); return; }
        add(t.getUniqueId(), amt);
        msg(p, "&aโอน $" + fmt(amt) + " ให้ " + t.getName());
        msg(t, "&aได้รับ $" + fmt(amt) + " จาก " + p.getName());
    }

    // ---------- TPA ----------
    void tpaCmd(Player p, String[] a, boolean here) {
        if (a.length < 1) { msg(p, "&e/" + (here ? "tphere" : "tpa") + " <player>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
        if (!setting(t.getUniqueId(), "tpa", true)) { msg(p, "&cผู้เล่นนี้ปิดรับคำขอวาป"); return; }
        if (setting(t.getUniqueId(), "tpauto", false)) { doTp(p, t, here); return; }
        tpaReqs.put(t.getUniqueId(), new TpaReq(p.getUniqueId(), here, System.currentTimeMillis() + 60_000));
        msg(p, "&aส่งคำขอไปยัง &e" + t.getName() + " &aแล้ว (หมดอายุใน 60 วินาที)");
        msg(t, "&e" + p.getName() + " &fขอ" + (here ? "ให้คุณวาปไปหาเขา" : "วาปมาหาคุณ") + " &7- พิมพ์ &a/tpaccept &7หรือ &c/tpdeny");
    }

    void doTp(Player requester, Player target, boolean here) {
        if (here) {
            target.teleportAsync(requester.getLocation());
            msg(target, "&aวาปไปหา &e" + requester.getName());
            msg(requester, "&e" + target.getName() + " &aวาปมาหาคุณแล้ว");
        } else {
            requester.teleportAsync(target.getLocation());
            msg(requester, "&aวาปไปหา &e" + target.getName());
            msg(target, "&e" + requester.getName() + " &aวาปมาหาคุณแล้ว");
        }
    }

    void tpRespond(Player p, boolean accept) {
        TpaReq r = tpaReqs.remove(p.getUniqueId());
        if (r == null || r.expire < System.currentTimeMillis()) { msg(p, "&cไม่มีคำขอวาปที่รออยู่"); return; }
        Player from = Bukkit.getPlayer(r.from);
        if (from == null) { msg(p, "&cผู้ขอออฟไลน์แล้ว"); return; }
        if (!accept) {
            msg(p, "&cปฏิเสธคำขอแล้ว");
            msg(from, "&c" + p.getName() + " ปฏิเสธคำขอวาปของคุณ");
            return;
        }
        doTp(from, p, r.here);
    }

    // ---------- /settings ----------
    private static final String[][] SETTINGS = {
            {"scoreboard", "แสดงสกอร์บอร์ด", "true", "OAK_SIGN"},
            {"tpauto", "รับ TPA อัตโนมัติ", "false", "ENDER_PEARL"},
            {"tpa", "รับคำขอ TPA/TPHERE", "true", "COMPASS"},
            {"pay", "รับเงินโอน (/pay)", "true", "GOLD_INGOT"}};
    private static final int[] SETTING_SLOTS = {10, 12, 14, 16};

    void fill(Inventory inv, Material m) {
        for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) inv.setItem(i, item(m, " "));
    }

    void openSettings(Player p) {
        Gui g = new Gui("settings");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lSettings"));
        for (int i = 0; i < SETTINGS.length; i++) {
            boolean on = setting(p.getUniqueId(), SETTINGS[i][0], Boolean.parseBoolean(SETTINGS[i][2]));
            g.inv.setItem(SETTING_SLOTS[i], item(Material.valueOf(SETTINGS[i][3]), "&f" + SETTINGS[i][1],
                    "", on ? "&a✔ เปิดอยู่" : "&c✘ ปิดอยู่", "", "&eคลิกเพื่อสลับ"));
            g.inv.setItem(SETTING_SLOTS[i] + 9, item(on ? Material.LIME_DYE : Material.GRAY_DYE,
                    on ? "&aเปิด" : "&cปิด", "&7คลิกเพื่อสลับ"));
        }
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // ---------- /homes GUI ----------
    void openHomes(Player p) {
        Gui g = new Gui("homes");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lHomes"));
        ConfigurationSection hs = data.getConfigurationSection("homes." + p.getUniqueId());
        if (hs != null) g.names.addAll(new TreeSet<>(hs.getKeys(false)));
        int max = Math.min(7, getConfig().getInt("homes.max", 3));
        for (int i = 0; i < max; i++) {
            if (i < g.names.size()) {
                String nm = g.names.get(i);
                Location l = data.getLocation("homes." + p.getUniqueId() + "." + nm);
                String loc = (l != null && l.getWorld() != null)
                        ? l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ() : "?";
                g.inv.setItem(10 + i, item(Material.RED_BED, "&a" + nm, "&7" + loc, "", "&eคลิกซ้าย = วาป", "&cShift+คลิกขวา = ลบ"));
            } else {
                g.inv.setItem(10 + i, item(Material.LIGHT_GRAY_BED, "&7ช่องบ้านว่าง", "&eคลิกเพื่อตั้งบ้านที่ตำแหน่งนี้"));
            }
        }
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    String nextHomeName(UUID id) {
        int n = 1;
        while (data.contains("homes." + id + ".home" + n)) n++;
        return "home" + n;
    }

    // ---------- /rules GUI ----------
    void openRules(Player p) {
        int size = Math.max(9, Math.min(54, getConfig().getInt("rules-gui.size", 27) / 9 * 9));
        Gui g = new Gui("rules");
        g.inv = Bukkit.createInventory(g, size, c(getConfig().getString("rules-gui.title", "&8Rules")));
        for (Map<?, ?> m : getConfig().getMapList("rules-gui.items")) {
            try {
                int slot = ((Number) m.get("slot")).intValue();
                Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                if (mat == null || slot < 0 || slot >= size) continue;
                List<String> lore = new ArrayList<>();
                Object lo = m.get("lore");
                if (lo instanceof List<?> ll) for (Object o : ll) lore.add(String.valueOf(o));
                g.inv.setItem(slot, item(mat, String.valueOf(m.get("name")), lore.toArray(new String[0])));
            } catch (Exception ignored) { }
        }
        Material fm = Material.matchMaterial(getConfig().getString("rules-gui.filler", "BLACK_STAINED_GLASS_PANE"));
        if (fm != null) fill(g.inv, fm);
        p.openInventory(g.inv);
    }

    // ---------- Virtual Spawner ----------
    String nice(EntityType t) {
        String n = t.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        return Character.toUpperCase(n.charAt(0)) + n.substring(1);
    }

    String key(Block b) { return b.getWorld().getName() + ":" + b.getX() + "," + b.getY() + "," + b.getZ(); }

    ItemStack spawnerItem(EntityType t, int amt) {
        ItemStack it = new ItemStack(Material.SPAWNER, amt);
        BlockStateMeta bm = (BlockStateMeta) it.getItemMeta();
        CreatureSpawner cs = (CreatureSpawner) bm.getBlockState();
        cs.setSpawnedType(t);
        bm.setBlockState(cs);
        bm.setDisplayName(c("&6" + nice(t) + " Spawner"));
        bm.setLore(List.of(c("&7วางแล้วคลิกขวามือเปล่าเพื่อเปิด"), c("&7คลิกขวาด้วยสปอว์นเนอร์ชนิดเดียวกันเพื่อซ้อน")));
        it.setItemMeta(bm);
        return it;
    }

    EntityType spawnerType(ItemStack it) {
        if (it == null || it.getType() != Material.SPAWNER) return null;
        if (it.getItemMeta() instanceof BlockStateMeta bm && bm.getBlockState() instanceof CreatureSpawner cs) return cs.getSpawnedType();
        return null;
    }

    boolean canUse(Player p, SpawnerData sd) {
        return !getConfig().getBoolean("spawner.owner-only", false) || sd.owner.equals(p.getUniqueId()) || p.hasPermission("donutsmp.admin");
    }

    @EventHandler
    public void onSpawnerPlace(BlockPlaceEvent e) {
        if (e.getBlockPlaced().getType() != Material.SPAWNER) return;
        EntityType t = spawnerType(e.getItemInHand());
        if (t == null) return;
        Block b = e.getBlockPlaced();
        SpawnerData sd = new SpawnerData(e.getPlayer().getUniqueId(), t, b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
        spawners.put(sd.id, sd);
        if (b.getState() instanceof CreatureSpawner cs) {
            cs.setSpawnedType(t);
            cs.setRequiredPlayerRange(0); // ปิดการเกิดมอนสเตอร์จริง ใช้ระบบเสมือนแทน
            cs.update();
        }
        msg(e.getPlayer(), "&aวางสปอว์นเนอร์ &e" + nice(t) + " &7(คลิกขวามือเปล่าเพื่อเปิด)");
    }

    @EventHandler
    public void onSpawnerInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.SPAWNER) return;
        SpawnerData sd = spawners.get(key(b));
        if (sd == null) return;
        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        boolean empty = hand == null || hand.getType().isAir();
        EntityType ht = spawnerType(hand);
        if (!empty && ht == null) return;
        if (!empty && p.isSneaking()) return;
        e.setCancelled(true);
        if (!canUse(p, sd)) { msg(p, "&cสปอว์นเนอร์นี้เป็นของคนอื่น"); return; }
        if (ht != null) {
            if (ht != sd.type) { msg(p, "&cชนิดสปอว์นเนอร์ไม่ตรงกัน"); return; }
            if (sd.stack + 1 > getConfig().getInt("spawner.max-stack", 1000)) { msg(p, "&cซ้อนได้สูงสุดแล้ว"); return; }
            sd.stack++;
            hand.setAmount(hand.getAmount() - 1);
            msg(p, "&aซ้อนสปอว์นเนอร์ ตอนนี้ &ex" + sd.stack);
            return;
        }
        openSpawner(p, sd, 0);
    }

    @EventHandler
    public void onSpawnerBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getType() != Material.SPAWNER) return;
        SpawnerData sd = spawners.get(key(b));
        if (sd == null) return;
        Player p = e.getPlayer();
        if (!canUse(p, sd)) { e.setCancelled(true); msg(p, "&cสปอว์นเนอร์นี้เป็นของคนอื่น"); return; }
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (getConfig().getBoolean("spawner.require-silk-touch", true)
                && !tool.containsEnchantment(Enchantment.SILK_TOUCH) && !p.hasPermission("donutsmp.admin")) {
            e.setCancelled(true);
            msg(p, "&cต้องใช้เครื่องมือที่มี Silk Touch");
            return;
        }
        e.setExpToDrop(0);
        e.setDropItems(false);
        int amount = Math.min(sd.stack, Math.max(1, getConfig().getInt("spawner.silk-break-amount", 64)));
        int rest = amount;
        while (rest > 0) { int st = Math.min(64, rest); give(p, spawnerItem(sd.type, st)); rest -= st; }
        if (sd.stack > amount) {
            sd.stack -= amount;
            e.setCancelled(true);
            msg(p, "&eเก็บสปอว์นเนอร์ " + amount + " อัน เหลือ &fx" + sd.stack);
        } else {
            spawners.remove(sd.id);
            msg(p, "&eเก็บสปอว์นเนอร์ x" + amount + " แล้ว (ของที่ยังไม่ได้เก็บในสปอว์นเนอร์จะหายไป)");
        }
    }

    @EventHandler
    public void onSpawnerExplode(EntityExplodeEvent e) {
        if (getConfig().getBoolean("spawner.explosion-protect", true))
            e.blockList().removeIf(b -> b.getType() == Material.SPAWNER && spawners.containsKey(key(b)));
    }

    void produceAll() {
        double dist = getConfig().getDouble("spawner.activation-distance", 16);
        double d2 = dist * dist;
        for (SpawnerData sd : spawners.values()) {
            World w = Bukkit.getWorld(sd.world);
            if (w == null) continue;
            boolean near = false;
            for (Player p : w.getPlayers()) {
                double dx = p.getX() - sd.x, dy = p.getY() - sd.y, dz = p.getZ() - sd.z;
                if (dx * dx + dy * dy + dz * dz <= d2) { near = true; break; }
            }
            if (near) produce(sd);
        }
    }

    void produce(SpawnerData sd) {
        long cap = getConfig().getLong("spawner.max-items", 50000);
        long total = sd.items.values().stream().mapToLong(Long::longValue).sum();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (String entry : getConfig().getStringList("spawner.drops." + sd.type.name())) {
            try {
                String[] a = entry.split(":");
                Material m = Material.matchMaterial(a[0]);
                if (m == null || sd.disabled.contains(m)) continue;
                String[] range = a[1].split("-");
                long lo = Long.parseLong(range[0]) * sd.stack, hi = Long.parseLong(range[1]) * sd.stack;
                long amt = lo >= hi ? lo : r.nextLong(lo, hi + 1);
                amt = Math.min(amt, Math.max(0, cap - total));
                if (amt <= 0) continue;
                sd.items.merge(m, amt, Long::sum);
                total += amt;
            } catch (Exception ignored) { }
        }
        long maxXp = getConfig().getLong("spawner.max-xp", 100000);
        sd.xp = Math.min(maxXp, sd.xp + getConfig().getLong("spawner.xp-per-cycle", 5) * sd.stack);
    }

    long takeFromSpawner(Player p, SpawnerData sd, Material m, long want) {
        long have = sd.items.getOrDefault(m, 0L);
        want = Math.min(want, have);
        long given = 0;
        while (given < want) {
            int st = (int) Math.min(want - given, m.getMaxStackSize());
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(m, st));
            int notGiven = left.values().stream().mapToInt(ItemStack::getAmount).sum();
            given += st - notGiven;
            if (notGiven > 0) break;
        }
        if (given > 0) {
            long rem = have - given;
            if (rem <= 0) sd.items.remove(m); else sd.items.put(m, rem);
        }
        return given;
    }

    void openSpawner(Player p, SpawnerData sd, int page) {
        List<Material> mats = new ArrayList<>(sd.items.keySet());
        mats.removeIf(m -> sd.items.getOrDefault(m, 0L) <= 0);
        mats.sort(Comparator.comparing(Enum::name));
        int pages = Math.max(1, (mats.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("spawner");
        g.sp = sd;
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8" + nice(sd.type) + " Spawner x" + sd.stack + " (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(mats.size(), page * 45 + 45); i++) {
            Material m = mats.get(i);
            long n = sd.items.get(m);
            ItemStack it = new ItemStack(m, (int) Math.min(n, m.getMaxStackSize()));
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&7เก็บอยู่: &f" + fmt(n)), c("&7มูลค่า: &a$" + fmt(n * sellPrice(m))),
                    c("&eคลิกซ้าย = เอา 1 สแต็ก"), c("&eShift+คลิก = เอาทั้งหมด")));
            it.setItemMeta(mt);
            g.inv.setItem(i - page * 45, it);
            g.mats.add(m);
        }
        long totalValue = 0;
        for (Map.Entry<Material, Long> en : sd.items.entrySet()) totalValue += (long) (en.getValue() * sellPrice(en.getKey()));
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« หน้าก่อนหน้า"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eหน้าถัดไป »"));
        g.inv.setItem(47, item(Material.GOLD_INGOT, "&6ขายทั้งหมด", "&7มูลค่ารวม: &a$" + fmt(totalValue), "&eคลิกเพื่อขาย"));
        g.inv.setItem(49, item(Material.EXPERIENCE_BOTTLE, "&aXP: &f" + fmt(sd.xp), "&eคลิกเพื่อรับ XP"));
        g.inv.setItem(51, item(Material.CHEST, "&bเอาของในหน้านี้ทั้งหมด", "&7ของจะเข้ากระเป๋า"));
        g.inv.setItem(46, item(Material.HOPPER, "&dเลือกของที่ไม่ให้เกิด", "&7ปิด/เปิดการดรอปทีละไอเทม", "&eคลิกเพื่อตั้งค่า"));
        g.inv.setItem(52, item(Material.BARRIER, "&cเก็บสปอว์นเนอร์ทั้งหมด x" + sd.stack, "&7ของในกงจะเข้ากระเป๋าก่อน", "&7แล้วสปอว์นเนอร์ดรอปลงพื้น", "&eคลิกเพื่อเก็บ"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void placeSpawner(World w, int x, int y, int z, EntityType t, int stack, UUID owner) {
        Block b = w.getBlockAt(x, y, z);
        spawners.remove(key(b));
        b.setType(Material.SPAWNER, false);
        if (b.getState() instanceof CreatureSpawner cs) {
            cs.setSpawnedType(t);
            cs.setRequiredPlayerRange(0);
            cs.update();
        }
        SpawnerData sd = new SpawnerData(owner, t, w.getName(), x, y, z);
        sd.stack = stack;
        spawners.put(sd.id, sd);
    }

    void openSpawnerFilter(Player p, SpawnerData sd) {
        Gui g = new Gui("spfilter");
        g.sp = sd;
        g.inv = Bukkit.createInventory(g, 54, c("&8เลือกของที่ไม่ให้เกิด - " + nice(sd.type)));
        int i = 0;
        for (String entry : getConfig().getStringList("spawner.drops." + sd.type.name())) {
            if (i >= 14) break;
            Material m = Material.matchMaterial(entry.split(":")[0]);
            if (m == null) continue;
            boolean off = sd.disabled.contains(m);
            int slot = 10 + (i % 7) + (i / 7) * 18;
            g.inv.setItem(slot, item(m, "&f" + m.name(), off ? "&c✘ ปิดการเกิดอยู่" : "&a✔ เกิดปกติ", "&eคลิกเพื่อสลับ"));
            g.inv.setItem(slot + 9, item(off ? Material.RED_STAINED_GLASS_PANE : Material.LIME_STAINED_GLASS_PANE,
                    off ? "&cไม่เกิด" : "&aเกิด", "&7คลิกเพื่อสลับ"));
            g.mats.add(m);
            i++;
        }
        g.inv.setItem(49, item(Material.ARROW, "&e« กลับ"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void pickupSpawner(Player p, SpawnerData sd) {
        for (Material m : new ArrayList<>(sd.items.keySet())) takeFromSpawner(p, sd, m, Long.MAX_VALUE);
        if (!sd.items.isEmpty()) { msg(p, "&cกระเป๋าเต็ม เอาของในกงออกให้หมดก่อน"); openSpawner(p, sd, 0); return; }
        World w = Bukkit.getWorld(sd.world);
        if (w == null) return;
        if (sd.xp > 0) { p.giveExp((int) Math.min(Integer.MAX_VALUE, sd.xp)); sd.xp = 0; }
        spawners.remove(sd.id);
        w.getBlockAt(sd.x, sd.y, sd.z).setType(Material.AIR);
        Location dl = new Location(w, sd.x + 0.5, sd.y + 0.5, sd.z + 0.5);
        int left = sd.stack;
        while (left > 0) {
            int st = Math.min(64, left);
            w.dropItemNaturally(dl, spawnerItem(sd.type, st));
            left -= st;
        }
        msg(p, "&aเก็บสปอว์นเนอร์ x" + sd.stack + " ดรอปลงพื้นแล้ว");
        Bukkit.getScheduler().runTask(this, p::closeInventory);
    }

    // ---------- Team ----------
    void teamCmd(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length == 0) { msg(p, "&e/team create <ชื่อ> | invite <ผู้เล่น> | accept | leave | info"); return; }
        String cur = data.getString("playerTeam." + id);
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (cur != null) { msg(p, "&cคุณอยู่ในทีมแล้ว"); return; }
                if (a.length < 2 || !a[1].matches("[A-Za-z0-9_]{2,12}")) { msg(p, "&e/team create <ชื่อ> &7(A-Z 0-9 _ ยาว 2-12 ตัว)"); return; }
                String key = a[1].toLowerCase(Locale.ROOT);
                if (data.contains("teams." + key)) { msg(p, "&cชื่อทีมนี้ถูกใช้แล้ว"); return; }
                data.set("teams." + key + ".name", a[1]);
                data.set("teams." + key + ".leader", id.toString());
                data.set("teams." + key + ".members", new ArrayList<>(List.of(id.toString())));
                data.set("playerTeam." + id, key);
                msg(p, "&aสร้างทีม &e" + a[1] + " &aแล้ว");
            }
            case "invite" -> {
                if (cur == null) { msg(p, "&cคุณยังไม่มีทีม"); return; }
                if (a.length < 2) { msg(p, "&e/team invite <ผู้เล่น>"); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null || t == p) { msg(p, "&cไม่พบผู้เล่น"); return; }
                if (data.getString("playerTeam." + t.getUniqueId()) != null) { msg(p, "&cผู้เล่นนี้มีทีมแล้ว"); return; }
                teamInvites.put(t.getUniqueId(), cur);
                msg(p, "&aเชิญ &e" + t.getName() + " &aแล้ว");
                msg(t, "&e" + p.getName() + " &fเชิญคุณเข้าทีม &e" + teamName(id) + " &7- พิมพ์ &a/team accept");
            }
            case "accept" -> {
                String key = teamInvites.remove(id);
                if (key == null || !data.contains("teams." + key)) { msg(p, "&cไม่มีคำเชิญ"); return; }
                if (cur != null) { msg(p, "&cคุณอยู่ในทีมแล้ว"); return; }
                List<String> members = data.getStringList("teams." + key + ".members");
                if (members.size() >= getConfig().getInt("team.max-members", 5)) { msg(p, "&cทีมเต็มแล้ว"); return; }
                members.add(id.toString());
                data.set("teams." + key + ".members", members);
                data.set("playerTeam." + id, key);
                msg(p, "&aเข้าร่วมทีม &e" + data.getString("teams." + key + ".name"));
            }
            case "leave" -> {
                if (cur == null) { msg(p, "&cคุณไม่มีทีม"); return; }
                List<String> members = data.getStringList("teams." + cur + ".members");
                if (id.toString().equals(data.getString("teams." + cur + ".leader"))) {
                    for (String m : members) data.set("playerTeam." + m, null);
                    data.set("teams." + cur, null);
                    msg(p, "&eคุณเป็นหัวหน้า ทีมถูกยุบแล้ว");
                } else {
                    members.remove(id.toString());
                    data.set("teams." + cur + ".members", members);
                    data.set("playerTeam." + id, null);
                    msg(p, "&eออกจากทีมแล้ว");
                }
            }
            case "info" -> {
                if (cur == null) { msg(p, "&cคุณไม่มีทีม"); return; }
                String names = data.getStringList("teams." + cur + ".members").stream()
                        .map(u -> Optional.ofNullable(Bukkit.getOfflinePlayer(UUID.fromString(u)).getName()).orElse("?"))
                        .collect(Collectors.joining(", "));
                msg(p, "&eทีม &f" + teamName(id) + " &7| สมาชิก: &f" + names);
            }
            default -> msg(p, "&e/team create | invite | accept | leave | info");
        }
    }

    // ---------- /shop ----------
    void openShop(Player p) {
        Gui g = new Gui("shop");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shop-title")));
        ConfigurationSection s = getConfig().getConfigurationSection("shop");
        if (s != null) for (String key : s.getKeys(false)) {
            Material m = Material.matchMaterial(key);
            if (m == null || !m.isItem()) continue;
            ItemStack it = new ItemStack(m);
            ItemMeta meta = it.getItemMeta();
            meta.setLore(List.of(c("&7ราคา: &a$" + fmt(s.getDouble(key)) + " &7/ชิ้น"), c("&eคลิกซ้าย = ซื้อ 1"), c("&eShift+คลิก = ซื้อ 64")));
            it.setItemMeta(meta);
            g.inv.addItem(it);
        }
        g.inv.setItem(53, item(Material.DIAMOND_CHESTPLATE, "&bชุดเกราะเพชรครบชุด (Keyall Set)",
                "&7ราคา: &a$" + fmt(getConfig().getDouble("shop-sets.diamond-armor-set", 25000)),
                "&7ได้ครบ 4 ชิ้น", "&eคลิกเพื่อซื้อ"));
        p.openInventory(g.inv);
    }

    // ---------- /sell (ขายได้ทุกอย่าง) ----------
    void openSell(Player p) {
        Gui g = new Gui("sell");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("sell-title")));
        p.openInventory(g.inv);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        Player p = (Player) e.getPlayer();
        if (g.type.equals("orderdeposit")) { finishDeposit(p, e.getInventory(), g.order); return; }
        if (!g.type.equals("sell")) return;
        double total = 0;
        int sold = 0;
        for (ItemStack it : e.getInventory().getContents()) {
            if (it == null || it.getType().isAir()) continue;
            double price = sellPrice(it.getType());
            if (price > 0) { total += price * it.getAmount(); sold += it.getAmount(); }
            else give(p, it);
        }
        e.getInventory().clear();
        if (total > 0) {
            add(p.getUniqueId(), total);
            msg(p, "&aขาย " + sold + " ชิ้น ได้เงิน &e$" + fmt(total));
        }
    }

    // ---------- /order ----------
    void orderCmd(Player p, String[] a) {
        if (a.length == 0) { openOrders(p, 0); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (a.length < 4) { msg(p, "&e/order create <item> <amount> <price ต่อชิ้น> &7(หรือพิมพ์ /order แล้วกดปุ่มสร้างออเดอร์)"); return; }
                Material m = Material.matchMaterial(a[1]);
                int amt;
                try { amt = Integer.parseInt(a[2]); } catch (NumberFormatException ex) { amt = -1; }
                double price = parseAmount(a[3]);
                if (m == null || !m.isItem() || m.isAir() || amt <= 0 || price <= 0) { msg(p, "&cข้อมูลไม่ถูกต้อง"); return; }
                createOrder(p, m, amt, price);
            }
            case "claim" -> claimAll(p);
            default -> openOrders(p, 0);
        }
    }

    boolean createOrder(Player p, Material m, int amt, double price) {
        UUID id = p.getUniqueId();
        long mine = orders.stream().filter(o -> o.owner.equals(id) && o.left > 0).count();
        if (mine >= getConfig().getInt("order.max-per-player", 10)) {
            msg(p, "&cสร้างออเดอร์ได้สูงสุด " + getConfig().getInt("order.max-per-player", 10) + " รายการ");
            return false;
        }
        if (amt > getConfig().getInt("order.max-amount", 1000000)) { msg(p, "&cจำนวนมากเกินไป"); return false; }
        double cost = amt * price;
        if (!take(id, cost)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(cost) + ")"); return false; }
        orders.add(new Order(nextOrderId++, id, m, amt, price));
        msg(p, "&aสร้างออเดอร์รับซื้อ " + m.name() + " x" + amt + " ราคา $" + fmt(price) + "/ชิ้น (ใช้เงิน $" + fmt(cost) + ")");
        return true;
    }

    void cancelOrder(Player p, Order o) {
        if (o.left > 0) {
            double refund = o.left * o.price;
            o.left = 0;
            add(p.getUniqueId(), refund);
            msg(p, "&aยกเลิกออเดอร์ คืนเงิน $" + fmt(refund));
        }
        cleanupOrder(o);
    }

    void cleanupOrder(Order o) { if (o.left <= 0 && o.delivered <= 0) orders.remove(o); }

    int addToInv(Player p, Material m, int want) {
        int given = 0;
        while (given < want) {
            int st = Math.min(want - given, m.getMaxStackSize());
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(m, st));
            int notGiven = left.values().stream().mapToInt(ItemStack::getAmount).sum();
            given += st - notGiven;
            if (notGiven > 0) break;
        }
        return given;
    }

    void takeDelivered(Player p, Order o, int amt) {
        int given = addToInv(p, o.mat, Math.min(amt, o.delivered));
        o.delivered -= given;
        if (given > 0) msg(p, "&aรับ " + o.mat.name() + " x" + given + " เข้ากระเป๋า");
        else msg(p, "&cกระเป๋าเต็ม");
        cleanupOrder(o);
    }

    void claimAll(Player p) {
        UUID id = p.getUniqueId();
        boolean any = false;
        Map<String, Integer> map = claims.remove(id);
        if (map != null) {
            for (Map.Entry<String, Integer> en : map.entrySet()) {
                Material m = Material.matchMaterial(en.getKey());
                if (m == null) continue;
                int left = en.getValue();
                while (left > 0) { int st = Math.min(left, m.getMaxStackSize()); give(p, new ItemStack(m, st)); left -= st; any = true; }
            }
        }
        for (Order o : new ArrayList<>(orders)) {
            if (!o.owner.equals(id) || o.delivered <= 0) continue;
            int given = addToInv(p, o.mat, o.delivered);
            o.delivered -= given;
            if (given > 0) any = true;
            cleanupOrder(o);
        }
        msg(p, any ? "&aรับของจากออเดอร์แล้ว" : "&cไม่มีของให้รับ (หรือกระเป๋าเต็ม)");
    }

    // หน้าหลัก: รายการรับซื้อทั้งหมด
    void openOrders(Player p, int page) {
        UUID id = p.getUniqueId();
        List<Order> open = orders.stream().filter(o -> o.left > 0)
                .sorted((x, y) -> Double.compare(y.price, x.price)).collect(Collectors.toList());
        int pages = Math.max(1, (open.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("orders");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("order-title", "&b&lออเดอร์รับซื้อ") + " &7(" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(open.size(), page * 45 + 45); i++) {
            Order o = open.get(i);
            ItemStack it = new ItemStack(o.mat);
            ItemMeta meta = it.getItemMeta();
            String owner = Optional.ofNullable(Bukkit.getOfflinePlayer(o.owner).getName()).orElse("?");
            List<String> lore = new ArrayList<>(List.of(
                    c("&7ผู้รับซื้อ: &f" + owner),
                    c("&7ต้องการอีก: &f" + o.left),
                    c("&7ราคาต่อชิ้น: &a$" + fmt(o.price)),
                    c("&7มูลค่ารวมที่เหลือ: &a$" + fmt(o.left * o.price)),
                    c("&aคลิกซ้าย = ฝากของ (วางไอเทมแล้วปิดหน้าต่าง)")));
            if (o.owner.equals(id)) lore.add(c("&cคลิกขวา = ยกเลิก (คืนเงิน)"));
            meta.setLore(lore);
            it.setItemMeta(meta);
            g.inv.setItem(g.orders.size(), it);
            g.orders.add(o);
        }
        long mine = orders.stream().filter(o -> o.owner.equals(id)).count();
        long deliveredTotal = orders.stream().filter(o -> o.owner.equals(id)).mapToLong(o -> o.delivered).sum();
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« หน้าก่อนหน้า"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eหน้าถัดไป »"));
        g.inv.setItem(47, item(Material.WRITABLE_BOOK, "&aสร้างออเดอร์รับซื้อ", "&7เลือกไอเทมได้ทุกอย่างในเกม", "&7แล้วตั้งราคา/จำนวนผ่านป้าย", "&eคลิกเพื่อเริ่ม"));
        g.inv.setItem(49, item(Material.CHEST, "&6กล่องออเดอร์ของฉัน",
                "&7ออเดอร์ของคุณ: &f" + mine, "&7ของที่มีคนฝากมา: &b" + deliveredTotal, "&eคลิกเพื่อเปิด"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // หน้าต่างฝากของ: วางไอเทมแล้วปิดหน้าต่างเพื่อส่งขายให้ออเดอร์
    void openDeposit(Player p, Order o) {
        Gui g = new Gui("orderdeposit");
        g.order = o;
        g.inv = Bukkit.createInventory(g, 54, c("&b&lฝาก &f" + o.mat.name() + " &7(ต้องการ " + o.left + " | $" + fmt(o.price) + "/ชิ้น)"));
        p.openInventory(g.inv);
        msg(p, "&eวาง &f" + o.mat.name() + " &eลงในหน้าต่าง แล้วปิดหน้าต่างเพื่อส่งขาย (ราคา $" + fmt(o.price) + "/ชิ้น)");
    }

    void finishDeposit(Player p, Inventory inv, Order o) {
        boolean valid = o != null && orders.contains(o) && o.left > 0 && !o.owner.equals(p.getUniqueId());
        int need = valid ? o.left : 0;
        int accepted = 0;
        List<ItemStack> back = new ArrayList<>();
        for (ItemStack it : inv.getContents()) {
            if (it == null || it.getType().isAir()) continue;
            if (valid && it.getType() == o.mat && !it.hasItemMeta() && need - accepted > 0) {
                int t = Math.min(it.getAmount(), need - accepted);
                accepted += t;
                if (it.getAmount() > t) {
                    ItemStack r = it.clone();
                    r.setAmount(it.getAmount() - t);
                    back.add(r);
                }
            } else back.add(it);
        }
        inv.clear();
        for (ItemStack r : back) give(p, r);
        if (accepted > 0) {
            double pay = accepted * o.price;
            add(p.getUniqueId(), pay);
            o.left -= accepted;
            o.delivered += accepted;
            msg(p, "&aฝาก " + o.mat.name() + " x" + accepted + " ได้เงิน &e$" + fmt(pay));
            Player owner = Bukkit.getPlayer(o.owner);
            if (owner != null) msg(owner, "&aมีคนฝาก " + o.mat.name() + " x" + accepted + " ให้ออเดอร์ของคุณ! เปิด &e/order &aแล้วกดรูปกล่องเพื่อรับของ");
        } else if (!valid) {
            msg(p, "&cออเดอร์นี้ปิดไปแล้ว ไอเทมถูกคืนให้คุณ");
        } else if (!back.isEmpty()) {
            msg(p, "&cไม่มีไอเทมที่ตรงกับออเดอร์ (ไอเทมที่มีชื่อ/เอนชานต์รับไม่ได้) คืนของให้แล้ว");
        }
    }

    // กล่องออเดอร์ของฉัน: เห็นทุกออเดอร์ที่ตัวเองรับซื้อ กดเข้าไปดูของที่คนฝากมา
    void openMyOrders(Player p) {
        UUID id = p.getUniqueId();
        Gui g = new Gui("myorders");
        g.inv = Bukkit.createInventory(g, 54, c("&6&lกล่องออเดอร์ของฉัน"));
        for (Order o : orders) {
            if (!o.owner.equals(id)) continue;
            if (g.orders.size() >= 45) break;
            ItemStack it = new ItemStack(o.mat);
            ItemMeta meta = it.getItemMeta();
            List<String> lore = new ArrayList<>();
            lore.add(c("&7ราคาต่อชิ้น: &a$" + fmt(o.price)));
            lore.add(c("&7ยังรับซื้ออีก: &f" + o.left));
            lore.add(c("&7ของที่มีคนฝากมา: &b" + o.delivered));
            lore.add(c("&aคลิกซ้าย = เปิดดูของที่ฝากมา"));
            if (o.left > 0) lore.add(c("&cคลิกขวา = ยกเลิก (คืนเงิน $" + fmt(o.left * o.price) + ")"));
            meta.setLore(lore);
            it.setItemMeta(meta);
            g.inv.setItem(g.orders.size(), it);
            g.orders.add(o);
        }
        if (g.orders.isEmpty()) g.inv.setItem(22, item(Material.BARRIER, "&cคุณยังไม่มีออเดอร์รับซื้อ", "&7กลับไปกด &aสร้างออเดอร์รับซื้อ"));
        g.inv.setItem(45, item(Material.ARROW, "&e« กลับไปหน้าออเดอร์"));
        g.inv.setItem(53, item(Material.HOPPER, "&bรับของทั้งหมด", "&7เอาของที่ฝากมาจากทุกออเดอร์เข้ากระเป๋า"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // หน้าต่างของที่มีคนฝากมาของออเดอร์นั้น
    void openCollect(Player p, Order o) {
        Gui g = new Gui("ordercollect");
        g.order = o;
        g.inv = Bukkit.createInventory(g, 54, c("&6ของที่ฝากมา: &f" + o.mat.name() + " &7(" + o.delivered + ")"));
        int left = o.delivered;
        for (int sl = 0; sl < 45 && left > 0; sl++) {
            int st = Math.min(left, o.mat.getMaxStackSize());
            ItemStack it = new ItemStack(o.mat, st);
            ItemMeta meta = it.getItemMeta();
            meta.setLore(List.of(c("&eคลิก = เอาสแต็กนี้"), c("&eShift+คลิก = เอาทั้งหมด")));
            it.setItemMeta(meta);
            g.inv.setItem(sl, it);
            left -= st;
        }
        g.inv.setItem(45, item(Material.ARROW, "&e« กลับ"));
        g.inv.setItem(49, item(Material.CHEST, "&bเอาทั้งหมด", "&7เหลือ: &f" + o.delivered));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // เลือกไอเทมที่จะรับซื้อ (ทุกไอเทมในเกม) + ค้นหา
    List<Material> allItems() {
        if (allItems == null) {
            allItems = Arrays.stream(Material.values())
                    .filter(m -> m.isItem() && !m.isAir() && !m.isLegacy())
                    .sorted(Comparator.comparing(Enum::name)).collect(Collectors.toList());
        }
        return allItems;
    }

    void openPicker(Player p, int page, String search) {
        List<Material> list = allItems();
        if (search != null && !search.isEmpty()) {
            String q = search.toLowerCase(Locale.ROOT).trim().replace(' ', '_');
            list = list.stream().filter(m -> m.name().toLowerCase(Locale.ROOT).contains(q)).collect(Collectors.toList());
        }
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("orderpick");
        g.page = page;
        g.search = search;
        g.inv = Bukkit.createInventory(g, 54, c("&8เลือกไอเทมที่จะรับซื้อ (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            Material m = list.get(i);
            ItemStack it = new ItemStack(m);
            ItemMeta meta = it.getItemMeta();
            meta.setLore(List.of(c("&7" + m.name()), c("&eคลิกเพื่อเลือก")));
            it.setItemMeta(meta);
            g.inv.setItem(g.mats.size(), it);
            g.mats.add(m);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« หน้าก่อนหน้า"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eหน้าถัดไป »"));
        g.inv.setItem(47, item(Material.OAK_SIGN, "&bค้นหาไอเทม", "&7ตอนนี้: &f" + (search == null ? "-" : search), "&eคลิกแล้วพิมพ์ชื่อบนป้าย"));
        if (search != null && !search.isEmpty()) g.inv.setItem(48, item(Material.BARRIER, "&cล้างการค้นหา"));
        g.inv.setItem(49, item(Material.ARROW, "&e« กลับไปหน้าออเดอร์"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // ---------- /ah ----------
    void ahCmd(Player p, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("sell")) {
            if (a.length < 2) { msg(p, "&e/ah sell <ราคา> &7(ถือของที่จะขายไว้ในมือ)"); return; }
            double price = parseAmount(a[1]);
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (price <= 0) { msg(p, "&cราคาไม่ถูกต้อง"); return; }
            if (hand == null || hand.getType().isAir()) { msg(p, "&cต้องถือของที่จะขายไว้ในมือ"); return; }
            long mine = listings.stream().filter(l -> l.seller.equals(p.getUniqueId())).count();
            if (mine >= getConfig().getInt("ah.max-listings", 10)) { msg(p, "&cลงขายได้สูงสุด " + getConfig().getInt("ah.max-listings", 10) + " รายการ"); return; }
            listings.add(new Listing(nextListingId++, p.getUniqueId(), hand.clone(), price, System.currentTimeMillis()));
            p.getInventory().setItemInMainHand(null);
            msg(p, "&aลงขาย &e" + hand.getType().name() + " x" + hand.getAmount() + " &aราคา &e$" + fmt(price));
            return;
        }
        openAh(p, 0);
    }

    void openAh(Player p, int page) {
        List<Listing> sorted = new ArrayList<>(listings);
        sorted.sort((x, y) -> Long.compare(y.time, x.time));
        int pages = Math.max(1, (sorted.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("ah");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&6&lAuction House &7(" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(sorted.size(), page * 45 + 45); i++) {
            Listing l = sorted.get(i);
            ItemStack d = l.item.clone();
            ItemMeta m = d.getItemMeta();
            List<String> lore = m.hasLore() && m.getLore() != null ? new ArrayList<>(m.getLore()) : new ArrayList<>();
            lore.add(c("&8──────────"));
            lore.add(c("&7ราคา: &a$" + fmt(l.price)));
            lore.add(c("&7ผู้ขาย: &f" + Optional.ofNullable(Bukkit.getOfflinePlayer(l.seller).getName()).orElse("?")));
            lore.add(c(l.seller.equals(p.getUniqueId()) ? "&cคลิกขวา = ยกเลิกการขาย" : "&aคลิกซ้าย = ซื้อ"));
            m.setLore(lore);
            d.setItemMeta(m);
            g.inv.setItem(g.shown.size(), d);
            g.shown.add(l);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« หน้าก่อนหน้า"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eหน้าถัดไป »"));
        g.inv.setItem(49, item(Material.PAPER, "&6วิธีลงขาย", "&7ถือของไว้ในมือแล้วพิมพ์", "&f/ah sell <ราคา>"));
        p.openInventory(g.inv);
    }

    void buyListing(Player p, Listing l) {
        if (l.seller.equals(p.getUniqueId())) { msg(p, "&cซื้อของตัวเองไม่ได้"); return; }
        if (!take(p.getUniqueId(), l.price)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(l.price) + ")"); return; }
        listings.remove(l);
        add(l.seller, l.price);
        give(p, l.item.clone());
        msg(p, "&aซื้อ " + l.item.getType().name() + " x" + l.item.getAmount() + " ราคา &e$" + fmt(l.price));
        Player seller = Bukkit.getPlayer(l.seller);
        if (seller != null) msg(seller, "&a" + p.getName() + " ซื้อ " + l.item.getType().name() + " ของคุณ ได้เงิน &e$" + fmt(l.price));
    }

    // ---------- คลิก GUI ----------
    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder(false) instanceof Gui g && !g.type.equals("sell") && !g.type.equals("orderdeposit")) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        if (g.type.equals("sell") || g.type.equals("orderdeposit")) return; // ให้วางของได้อิสระ
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || it.getType().isAir()) return;
        Player p = (Player) e.getWhoClicked();
        int slot = e.getSlot();

        switch (g.type) {
            case "shop" -> {
                if (slot == 53 && it.getType() == Material.DIAMOND_CHESTPLATE) {
                    double setPrice = getConfig().getDouble("shop-sets.diamond-armor-set", 25000);
                    if (!take(p.getUniqueId(), setPrice)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(setPrice) + ")"); return; }
                    giveArmorSet(p);
                    msg(p, "&aซื้อชุดเกราะเพชรครบชุด ราคา $" + fmt(setPrice));
                    return;
                }
                int amt = e.isShiftClick() ? 64 : 1;
                double price = getConfig().getDouble("shop." + it.getType().name(), -1);
                if (price < 0) return;
                double total = price * amt;
                if (!take(p.getUniqueId(), total)) { msg(p, "&cเงินไม่พอ (ต้องใช้ $" + fmt(total) + ")"); return; }
                give(p, new ItemStack(it.getType(), amt));
                msg(p, "&aซื้อ " + it.getType().name() + " x" + amt + " ราคา $" + fmt(total));
            }
            case "orders" -> {
                UUID uid = p.getUniqueId();
                if (slot == 45 && it.getType() == Material.ARROW) { openOrders(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openOrders(p, g.page + 1); return; }
                if (slot == 47) { openPicker(p, 0, null); return; }
                if (slot == 49) { openMyOrders(p); return; }
                if (slot >= g.orders.size()) return;
                Order o = g.orders.get(slot);
                if (!orders.contains(o) || o.left <= 0) { openOrders(p, g.page); return; }
                if (e.isRightClick() && o.owner.equals(uid)) {
                    cancelOrder(p, o);
                    openOrders(p, g.page);
                } else if (e.isLeftClick()) {
                    if (o.owner.equals(uid)) { msg(p, "&cฝากของให้ออเดอร์ตัวเองไม่ได้ (คลิกขวา = ยกเลิก)"); return; }
                    openDeposit(p, o);
                }
            }
            case "orderpick" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openPicker(p, g.page - 1, g.search); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openPicker(p, g.page + 1, g.search); return; }
                if (slot == 47) { openSign(p, "search", null, 0, g.search, "พิมพ์ชื่อไอเทม (อังกฤษ)", "เช่น diamond"); return; }
                if (slot == 48 && it.getType() == Material.BARRIER) { openPicker(p, 0, null); return; }
                if (slot == 49) { openOrders(p, 0); return; }
                if (slot < g.mats.size()) {
                    openSign(p, "price", g.mats.get(slot), 0, g.search, "ราคาต่อชิ้น", "เช่น 500 หรือ 1.5k");
                }
            }
            case "myorders" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openOrders(p, 0); return; }
                if (slot == 53 && it.getType() == Material.HOPPER) { claimAll(p); openMyOrders(p); return; }
                if (slot >= g.orders.size()) return;
                Order o = g.orders.get(slot);
                if (!orders.contains(o)) { openMyOrders(p); return; }
                if (e.isRightClick()) {
                    if (o.left > 0) cancelOrder(p, o);
                    openMyOrders(p);
                } else if (e.isLeftClick()) {
                    openCollect(p, o);
                }
            }
            case "ordercollect" -> {
                Order o = g.order;
                if (slot == 45 && it.getType() == Material.ARROW) { openMyOrders(p); return; }
                if (o == null || !orders.contains(o)) { openMyOrders(p); return; }
                if (slot == 49) takeDelivered(p, o, o.delivered);
                else if (slot < 45 && it.getType() == o.mat) takeDelivered(p, o, e.isShiftClick() ? o.delivered : it.getAmount());
                else return;
                if (orders.contains(o)) openCollect(p, o); else openMyOrders(p);
            }
            case "spfilter" -> {
                SpawnerData sd = g.sp;
                if (sd == null || !spawners.containsKey(sd.id)) { p.closeInventory(); return; }
                if (slot == 49) { openSpawner(p, sd, 0); return; }
                for (int i = 0; i < g.mats.size(); i++) {
                    int base = 10 + (i % 7) + (i / 7) * 18;
                    if (slot != base && slot != base + 9) continue;
                    Material dm = g.mats.get(i);
                    if (!sd.disabled.remove(dm)) sd.disabled.add(dm);
                    break;
                }
                openSpawnerFilter(p, sd);
            }
            case "rtp" -> {
                World.Environment env = slot == 11 ? World.Environment.NORMAL
                        : slot == 13 ? World.Environment.NETHER
                        : slot == 15 ? World.Environment.THE_END : null;
                if (env == null) return;
                Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); rtp(p, env); });
            }
            case "settings" -> {
                for (int i = 0; i < SETTING_SLOTS.length; i++) {
                    if (SETTING_SLOTS[i] != slot && SETTING_SLOTS[i] + 9 != slot) continue;
                    String key = SETTINGS[i][0];
                    boolean cur = setting(p.getUniqueId(), key, Boolean.parseBoolean(SETTINGS[i][2]));
                    setSetting(p.getUniqueId(), key, !cur);
                    break;
                }
                openSettings(p);
                updateBoard(p);
            }
            case "homes" -> {
                int idx = slot - 10;
                if (idx < 0 || idx >= Math.min(7, getConfig().getInt("homes.max", 3))) return;
                UUID pid = p.getUniqueId();
                if (idx < g.names.size()) {
                    String hname = g.names.get(idx);
                    String path = "homes." + pid + "." + hname;
                    if (e.isShiftClick() && e.isRightClick()) {
                        data.set(path, null);
                        msg(p, "&aลบบ้าน &e" + hname + " &aแล้ว");
                        openHomes(p);
                        return;
                    }
                    Location hl = data.getLocation(path);
                    if (hl == null) { openHomes(p); return; }
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        p.teleportAsync(hl);
                        msg(p, "&aวาปไปบ้าน &e" + hname);
                    });
                } else {
                    String nn = nextHomeName(pid);
                    data.set("homes." + pid + "." + nn, p.getLocation());
                    msg(p, "&aตั้งบ้าน &e" + nn + " &aแล้ว");
                    openHomes(p);
                }
            }
            case "shardshop" -> {
                Integer sidx = g.slotIdx.get(slot);
                if (sidx == null) return;
                long price = g.prices.get(sidx);
                UUID pid = p.getUniqueId();
                long have = shards.getOrDefault(pid, 0L);
                if (have < price) { msg(p, "&cShards ไม่พอ (ต้องใช้ " + fmt(price) + ")"); return; }
                shards.put(pid, have - price);
                for (ItemStack gi : g.goods.get(sidx)) give(p, gi.clone());
                msg(p, "&aซื้อสำเร็จ! ใช้ &d" + fmt(price) + " Shards");
                openShardShop(p);
            }
            case "spawner" -> {
                SpawnerData sd = g.sp;
                if (sd == null || !spawners.containsKey(sd.id)) { p.closeInventory(); return; }
                if (slot == 45 && it.getType() == Material.ARROW) { openSpawner(p, sd, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openSpawner(p, sd, g.page + 1); return; }
                if (slot == 47) {
                    double total = 0;
                    for (Map.Entry<Material, Long> en : sd.items.entrySet()) total += en.getValue() * sellPrice(en.getKey());
                    if (total <= 0) { msg(p, "&cไม่มีของให้ขาย"); return; }
                    sd.items.clear();
                    add(p.getUniqueId(), total);
                    msg(p, "&aขายของในสปอว์นเนอร์ ได้ &e$" + fmt(total));
                    openSpawner(p, sd, 0);
                    return;
                }
                if (slot == 49) {
                    if (sd.xp > 0) {
                        p.giveExp((int) Math.min(Integer.MAX_VALUE, sd.xp));
                        msg(p, "&aรับ XP " + fmt(sd.xp));
                        sd.xp = 0;
                    }
                    openSpawner(p, sd, g.page);
                    return;
                }
                if (slot == 51) {
                    for (Material m : new ArrayList<>(g.mats)) takeFromSpawner(p, sd, m, Long.MAX_VALUE);
                    openSpawner(p, sd, g.page);
                    return;
                }
                if (slot == 46) { openSpawnerFilter(p, sd); return; }
                if (slot == 52) { pickupSpawner(p, sd); return; }
                if (slot < 45 && slot < g.mats.size()) {
                    Material m = g.mats.get(slot);
                    takeFromSpawner(p, sd, m, e.isShiftClick() ? Long.MAX_VALUE : m.getMaxStackSize());
                    openSpawner(p, sd, g.page);
                }
            }
            case "ah" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openAh(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openAh(p, g.page + 1); return; }
                if (slot >= g.shown.size()) return;
                Listing l = g.shown.get(slot);
                if (!listings.contains(l)) { openAh(p, g.page); return; }
                if (e.isRightClick() && l.seller.equals(p.getUniqueId())) {
                    listings.remove(l);
                    give(p, l.item.clone());
                    msg(p, "&eยกเลิกการขายแล้ว ได้ของคืน");
                } else if (e.isLeftClick()) {
                    buyListing(p, l);
                }
                openAh(p, g.page);
            }
        }
    }

    // ---------- /rtp ----------
    void rtpCmd(Player p, String[] a) {
        if (a.length == 0) { openRtp(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "overworld", "ow", "world", "normal" -> rtp(p, World.Environment.NORMAL);
            case "nether", "hell" -> rtp(p, World.Environment.NETHER);
            case "end", "the_end" -> rtp(p, World.Environment.THE_END);
            default -> openRtp(p);
        }
    }

    void openRtp(Player p) {
        Gui g = new Gui("rtp");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lRTP - เลือกมิติ"));
        g.inv.setItem(11, item(Material.GRASS_BLOCK, "&aโอเวอร์เวิลด์", "&7คลิกเพื่อสุ่มวาป"));
        g.inv.setItem(13, item(Material.NETHERRACK, "&cเนเธอร์ (นรก)", "&7คลิกเพื่อสุ่มวาป"));
        g.inv.setItem(15, item(Material.END_STONE, "&dดิ เอนด์", "&7คลิกเพื่อสุ่มวาป"));
        p.openInventory(g.inv);
    }

    World findWorld(World.Environment env) {
        return Bukkit.getWorlds().stream().filter(w -> w.getEnvironment() == env).findFirst().orElse(null);
    }

    void rtp(Player p, World.Environment env) {
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("rtp.cooldown", 10) * 1000;
        Long last = rtpCooldown.get(p.getUniqueId());
        if (last != null && now - last < cd) { msg(p, "&cรออีก " + ((cd - (now - last)) / 1000 + 1) + " วินาที"); return; }
        World w = findWorld(env);
        if (w == null) { msg(p, "&cไม่พบโลกมิตินี้ในเซิร์ฟเวอร์"); return; }
        rtpCooldown.put(p.getUniqueId(), now);
        msg(p, "&eกำลังสุ่มตำแหน่ง...");
        tryRtp(p, w, 0, env == World.Environment.THE_END ? 80 : env == World.Environment.NORMAL ? 40 : 20);
    }

    void tryRtp(Player p, World w, int tries, int maxTries) {
        if (tries >= maxTries) { msg(p, "&cหาตำแหน่งปลอดภัยไม่ได้ ลองใหม่อีกครั้ง"); rtpCooldown.remove(p.getUniqueId()); return; }
        String key = switch (w.getEnvironment()) { case NETHER -> "nether"; case THE_END -> "end"; default -> "overworld"; };
        int defMin = switch (key) { case "nether" -> 300; case "end" -> 1200; default -> 500; };
        int defMax = switch (key) { case "nether" -> 31250; case "end" -> 4000; default -> 250000; };
        Location ctr = w.getWorldBorder().getCenter();
        int max = (int) Math.min(getConfig().getInt("rtp." + key + ".max", defMax), w.getWorldBorder().getSize() / 2 - 16);
        int min = Math.min(getConfig().getInt("rtp." + key + ".min", defMin), max / 2);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = min + r.nextDouble() * (max - min);
        int x = (int) (ctr.getX() + Math.cos(ang) * dist);
        int z = (int) (ctr.getZ() + Math.sin(ang) * dist);
        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(ch -> Bukkit.getScheduler().runTask(this, () -> {
            if (!p.isOnline()) return;
            Location loc = findSafe(w, x, z);
            if (loc == null) { tryRtp(p, w, tries + 1, maxTries); return; }
            p.teleportAsync(loc).thenAccept(ok -> {
                if (ok) msg(p, "&aวาปแล้ว! &7X: " + x + " Z: " + z);
            });
        }));
    }

    Location findSafe(World w, int x, int z) {
        if (w.getEnvironment() == World.Environment.NETHER) {
            for (int y = 120; y >= 33; y--) {
                Block b = w.getBlockAt(x, y, z);
                if (isSafe(b)) return new Location(w, x + 0.5, y + 1, z + 0.5);
            }
            return null;
        }
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (y < w.getMinHeight()) return null;
        Block b = w.getBlockAt(x, y, z);
        return isSafe(b) ? new Location(w, x + 0.5, y + 1, z + 0.5) : null;
    }

    boolean isSafe(Block b) {
        Material t = b.getType();
        if (!t.isSolid() || Tag.LEAVES.isTagged(t)) return false;
        switch (t) {
            case MAGMA_BLOCK, CACTUS, CAMPFIRE, SOUL_CAMPFIRE, POWDER_SNOW, SWEET_BERRY_BUSH,
                 WITHER_ROSE, CHORUS_PLANT, CHORUS_FLOWER, BEDROCK -> { return false; }
            default -> { }
        }
        for (int i = 1; i <= 2; i++) {
            Block a = b.getRelative(0, i, 0);
            Material at = a.getType();
            if (!a.isPassable() || a.isLiquid() || at == Material.FIRE || at == Material.SOUL_FIRE || at == Material.LAVA) return false;
        }
        return true;
    }

    // ---------- Tab complete ----------
    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        if ((n.equals("home") || n.equals("delhome")) && a.length == 1 && s instanceof Player p) {
            ConfigurationSection hs = data.getConfigurationSection("homes." + p.getUniqueId());
            return hs == null ? List.of() : hs.getKeys(false).stream().filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if ((n.equals("pay") || n.equals("tpa") || n.equals("tphere")) && a.length == 1) return names(a[0]);
        if (n.equals("eco")) {
            if (a.length == 1) return List.of("give", "take", "set");
            if (a.length == 2) return names(a[1]);
            if (a.length == 3) return List.of("money", "shards", "keyall");
        }
        if (n.equals("rtp") && a.length == 1) return List.of("overworld", "nether", "end");
        if (n.equals("shards")) {
            if (a.length == 1) return List.of("pay");
            if (a.length == 2 && a[0].equalsIgnoreCase("pay")) return names(a[1]);
        }
        if (n.equals("spawner")) {
            if (a.length == 1) return List.of("give", "fill", "fillinv");
            if (a.length == 2 && (a[0].equalsIgnoreCase("fill") || a[0].equalsIgnoreCase("fillinv"))) return mobs(a[1]);
            if (a.length == 3 && a[0].equalsIgnoreCase("fill")) return List.of("3", "5", "9", "16");
            if (a.length == 2) return names(a[1]);
            if (a.length == 3) return Arrays.stream(EntityType.values()).filter(EntityType::isAlive).map(t -> t.name().toLowerCase(Locale.ROOT))
                    .filter(k -> k.startsWith(a[2].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        if (n.equals("givera")) {
            if (a.length == 1) return names(a[0]);
            if (a.length == 2) return Stream.of("OWNER", "ADMIN", "CAMERA", "remove")
                    .filter(k -> k.toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if (n.equals("ah") && a.length == 1) return List.of("sell");
        if (n.equals("team")) {
            if (a.length == 1) return List.of("create", "invite", "accept", "leave", "info");
            if (a.length == 2 && a[0].equalsIgnoreCase("invite")) return names(a[1]);
        }
        if (n.equals("order")) {
            if (a.length == 1) return List.of("create", "claim");
            if (a.length == 2 && a[0].equalsIgnoreCase("create"))
                return Arrays.stream(Material.values()).filter(Material::isItem).map(m -> m.name().toLowerCase(Locale.ROOT))
                        .filter(k -> k.startsWith(a[1].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        return List.of();
    }
}
